﻿using System;  
using System.Windows.Forms;  
using System.IO.Ports;  
using System.Diagnostics;  
using DocumentFormat.OpenXml.Office2010.Excel;  
using System.Text;  
using SpeechLib;  
  
namespace clientmachine
{
    public partial class Form1 : Form
    {
        String RSsign = null;
        String Langua = null;
        SerialPort s = new SerialPort();
        public Form1()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
            int[] item = { 9600, 56000, 115200 };
            foreach (int a in item)
            {
                comboBox2.Items.Add(a.ToString());
            }

            comboBox2.SelectedItem = comboBox2.Items[0];
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!s.IsOpen)
                {
                    s.PortName = comboBox1.SelectedItem.ToString();
                    s.BaudRate = Convert.ToInt32(comboBox2.SelectedItem.ToString());
                    s.WriteTimeout = 1000;
                    s.Open();
                    s.DataReceived += s_DataReceived;
                    if (Langua == "ENG")
                    {
                        button1.Text = "Close";
                    }
                    else
                    {
                        button1.Text = "关闭串口";
                    }
                }
                else
                {
                    s.Close();
                    s.DataReceived -= s_DataReceived;
                    if (Langua == "ENG")
                    {
                        button1.Text = "Open";
                    }
                    else
                    {
                        button1.Text = "打开串口";
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
        }

        void s_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (s.BytesToRead <= 0)
            {
                return;
            }
            int count = s.BytesToRead;
            string str = null;
            byte[] buff = new byte[count];
            try
            {
                s.Read(buff, 0, count);
                foreach (byte item in buff)
                {
                    str += item.ToString("X2") + " ";
                }
            }
            catch (System.Exception)
            {

            }
            if (RSsign == "HEX")
            {
                richTextBox1.AppendText(str);
            }
            else
            {
                richTextBox1.AppendText(Encoding.Default.GetString(buff));
            }

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (RSsign == "HEX")
            {
                string[] sendbuff = richTextBox2.Text.Split();
                Debug.WriteLine("send byte：" + sendbuff.Length);
                foreach (string item in sendbuff)
                {
                    int count = 1;
                    byte[] buff = new byte[count];
                    s.Write(buff, 0, count);
                }
            }
            else
            {
                s.Write(richTextBox2.Text.Trim());
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            comboBox1.Items.AddRange(ports);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Langua = "ENG";
            //english  
            groupBox1.Text = "Serialport Settings";
            label1.Text = "Choose Port";
            label2.Text = "Boud Rate";
            groupBox2.Text = "R&S Settings";
            groupBox3.Text = "Language";
            label3.Text = "Info";
            label4.Text = "Send Info";
            button2.Text = "Send";
            button1.Text = "Open";
            button5.Text = "Warning";
            string text = "English mode on";
            SpVoice voice = new SpVoice();

            voice.Volume = 100;

            voice.Rate = 2;

            voice.Speak(text);

        }
        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Langua = "CHN";
            //chinese  
            groupBox1.Text = "串口设置";
            label1.Text = "选择串口";
            label2.Text = "波特率";
            groupBox2.Text = "接发设置";
            groupBox3.Text = "语言设置";
            label3.Text = "信息";
            label4.Text = "发送信息";
            button2.Text = "发送";
            button1.Text = "打开串口";
            button5.Text = "警报";
            string text = "中文模式开启";
            SpVoice voice = new SpVoice();

            voice.Volume = 100;

            voice.Rate = 2;

            voice.Speak(text);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            RSsign = "HEX";
        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            RSsign = "ASC";
        }
    }

}

